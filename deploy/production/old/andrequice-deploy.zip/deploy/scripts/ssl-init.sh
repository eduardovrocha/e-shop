#!/usr/bin/env bash
# ─── ssl-init.sh — Emissão inicial de certificados Let's Encrypt ─────────────
# Executar UMA VEZ após o deploy inicial, com Nginx já rodando na porta 80.
# Os domínios precisam estar apontando para o IP da VPS antes de rodar.
# ────────────────────────────────────────────────────────────────────────────
set -euo pipefail

APP_DIR="/home/deploy/andrequice"
COMPOSE="docker compose -f ${APP_DIR}/deploy/production/docker-compose.yml --env-file ${APP_DIR}/.env"

# ── Ajustar domínios e email ────────────────────────────────────────────────
DOMAIN_FRONTEND="andrequice.com.br"
DOMAIN_API="api.andrequice.com.br"
DOMAIN_DASHBOARD="dashboard.andrequice.com.br"
EMAIL="seu-email@andrequice.com.br"   # recebe alertas de expiração

echo "==> Iniciando apenas o Nginx (para ACME challenge)..."
${COMPOSE} up -d nginx

sleep 3

echo "==> Emitindo certificado para ${DOMAIN_FRONTEND} e www..."
docker run --rm \
  -v "${APP_DIR}/deploy/production/certbot_conf:/etc/letsencrypt" \
  -v "${APP_DIR}/deploy/production/certbot_www:/var/www/certbot" \
  certbot/certbot certonly \
    --webroot \
    --webroot-path /var/www/certbot \
    --email "${EMAIL}" \
    --agree-tos \
    --no-eff-email \
    -d "${DOMAIN_FRONTEND}" \
    -d "www.${DOMAIN_FRONTEND}"

echo "==> Emitindo certificado para ${DOMAIN_API}..."
docker run --rm \
  -v "${APP_DIR}/deploy/production/certbot_conf:/etc/letsencrypt" \
  -v "${APP_DIR}/deploy/production/certbot_www:/var/www/certbot" \
  certbot/certbot certonly \
    --webroot \
    --webroot-path /var/www/certbot \
    --email "${EMAIL}" \
    --agree-tos \
    --no-eff-email \
    -d "${DOMAIN_API}"

echo "==> Emitindo certificado para ${DOMAIN_DASHBOARD}..."
docker run --rm \
  -v "${APP_DIR}/deploy/production/certbot_conf:/etc/letsencrypt" \
  -v "${APP_DIR}/deploy/production/certbot_www:/var/www/certbot" \
  certbot/certbot certonly \
    --webroot \
    --webroot-path /var/www/certbot \
    --email "${EMAIL}" \
    --agree-tos \
    --no-eff-email \
    -d "${DOMAIN_DASHBOARD}"

echo "==> Recarregando Nginx com SSL ativado..."
${COMPOSE} exec nginx nginx -s reload

echo ""
echo "✓ Certificados emitidos. SSL ativo para todos os domínios."
echo "  Renovação automática: o serviço certbot no compose roda a cada 12h."
